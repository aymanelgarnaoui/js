# javascript-interactive-photo-gallery
a simple gallery application built with javascript which displays the image in bigger frame with the text describing it(Alt text)  when you hover the mouse over the image 
